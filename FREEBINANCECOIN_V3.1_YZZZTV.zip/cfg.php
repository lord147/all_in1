<?php

$useragent = "xxxx";

$cookie = "xxxx";

//isi hanya dengan angka 5, 20, atau 100
$buy = "xxxx";