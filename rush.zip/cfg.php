<?php
/*untuk menjalankan scrip harap install bahan² dibawah ini
pkg install php
pkg install imagemagick
pkg install tesseract
*/

$UA = "xxxxxxx";

$COOKIE = "xxxxxxxx";

$SOLVEMEDIA = "xxxxxxx";

?>
